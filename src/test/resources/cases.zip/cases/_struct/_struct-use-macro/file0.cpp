#define Mystruct struct 
Mystruct cell{
    int value;
};