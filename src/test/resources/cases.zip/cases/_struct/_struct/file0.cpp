struct MyStruct {
    int value;
};