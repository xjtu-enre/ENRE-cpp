struct{
    int value;
};