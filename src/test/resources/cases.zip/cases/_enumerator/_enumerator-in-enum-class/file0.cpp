namespace CardGame_Scoped
{
    enum class Suit { Diamonds, Hearts, Clubs, Spades };
}