    enum Color { 
        red, 
        green, 
        blue 
    };