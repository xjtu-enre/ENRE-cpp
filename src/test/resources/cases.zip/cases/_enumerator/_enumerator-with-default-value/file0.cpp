enum DAY {
    saturday,
    sunday = 0,
    monday,
    tuesday,
    wednesday, 
    thursday,
    friday
} workday;