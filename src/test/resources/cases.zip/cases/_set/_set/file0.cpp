int func(int i){
    int j;
    j = i;
}