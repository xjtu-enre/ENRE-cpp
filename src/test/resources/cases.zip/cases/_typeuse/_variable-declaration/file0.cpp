class MyClass {
    // MyClass details
};

void function() {
    MyClass obj;
}