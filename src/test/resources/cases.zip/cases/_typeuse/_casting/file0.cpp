class AnotherClass {
    // AnotherClass details
};

void example() {
    void* ptr;
    AnotherClass* ac = static_cast<AnotherClass*>(ptr);
}