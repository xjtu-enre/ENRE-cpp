struct MyStruct {
    // MyStruct details
};

void process(MyStruct s) {
    // process logic
}