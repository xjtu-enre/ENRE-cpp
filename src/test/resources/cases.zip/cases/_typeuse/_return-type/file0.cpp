enum MyEnum {
    VALUE1, VALUE2
};

MyEnum getStatus() {
    return VALUE1;
}