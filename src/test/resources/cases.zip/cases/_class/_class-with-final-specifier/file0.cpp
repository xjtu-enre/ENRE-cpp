class Vector final {
};