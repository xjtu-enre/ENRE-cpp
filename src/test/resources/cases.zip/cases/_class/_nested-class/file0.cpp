class enclose
{
    class nested // private member
    {
    };
};