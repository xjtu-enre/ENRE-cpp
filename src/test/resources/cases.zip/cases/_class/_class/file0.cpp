class Base { /* empty */};
class Extend : public Base {/* empty */ };