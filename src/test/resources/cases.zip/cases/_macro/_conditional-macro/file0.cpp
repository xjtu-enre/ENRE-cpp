#define EMPTY
#ifdef EMPTY
#define FULL
#endif