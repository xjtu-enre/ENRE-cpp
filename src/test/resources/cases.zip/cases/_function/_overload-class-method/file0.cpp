class foo{
public:
    int overloadFunction();
    int overloadFunction(int i);
    int overloadFunction(char i);
}