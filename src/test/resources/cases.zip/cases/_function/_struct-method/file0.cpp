struct Linear {
    int func() {
        return 0;
    }
};