class Account {
public:
    virtual void func(){ /* empty */ }
}