struct deletedFunction
{
  deletedFunction() =default;
  deletedFunction(const noncopyable&) =delete;
};