enum weekday {
    Monday = 1;
    Tuesday = 2;
    Wednesday = 3;
};