class Units{
    int x;
};
int main(){
    Units unit;
}