int i = 0;
int j = i++;