int func(){
    int i = 0;
    i++;
}