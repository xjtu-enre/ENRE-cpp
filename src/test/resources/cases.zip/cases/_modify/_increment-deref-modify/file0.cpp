int main(){
    int *a,*b=0;
    ++*a; // deref modify of a
}