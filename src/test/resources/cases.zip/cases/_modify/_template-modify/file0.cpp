template<typename T>
void func(){
    int i = 0;
    i++;
}