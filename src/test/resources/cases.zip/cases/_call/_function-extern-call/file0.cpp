extern int func1(void);
int func() {
    func1();
}