int func(){
    return 0;
}
template<typename S>
void func2(S &s){
    func();
}