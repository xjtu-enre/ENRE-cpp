template<typename S>
int func(S &s){
    return 0;
}
void func2(){
    int s = 0;
    func(s);
}