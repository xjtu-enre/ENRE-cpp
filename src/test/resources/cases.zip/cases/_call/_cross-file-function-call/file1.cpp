#include "file0.h"
void epoll(){
    run_benchmark();
    Dog dog;
    dog.bark();
}