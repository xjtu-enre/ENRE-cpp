void run_benchmark() {}
class Dog{
public:
    void bark(){}
}