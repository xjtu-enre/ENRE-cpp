void run_benchmark() {}
void epoll(){
    run_benchmark();
}