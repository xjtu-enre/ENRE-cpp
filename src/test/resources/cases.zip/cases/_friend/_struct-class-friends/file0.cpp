class c{};
struct X {
    friend class c;
};