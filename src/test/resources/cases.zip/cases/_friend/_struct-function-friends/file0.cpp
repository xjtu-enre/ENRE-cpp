struct X {
    friend void f() {}
};
void f();