class Outer {
    class Inner {};
};