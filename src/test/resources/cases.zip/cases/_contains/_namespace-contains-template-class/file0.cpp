namespace MyNamespace {
    template <typename T>
    class MyTemplateClass {};
};