template <typename T>
class TemplateClass {
    void doSomething() {}
};