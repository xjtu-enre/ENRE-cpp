class SomeClass {
    template <typename T>
    void genericMethod() {}
};