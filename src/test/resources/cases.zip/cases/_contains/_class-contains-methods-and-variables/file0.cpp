class Animal {
public:
    void speak() {}
    int age;
};