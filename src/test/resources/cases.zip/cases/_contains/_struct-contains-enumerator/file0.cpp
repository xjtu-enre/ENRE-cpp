struct Options {
    enum Choice { FIRST, SECOND };
};