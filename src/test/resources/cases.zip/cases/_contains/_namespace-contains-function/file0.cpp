namespace Tools {
    void runTool() {}
}
