struct Point { \* empty *\ };
union U{
    Point p;
};