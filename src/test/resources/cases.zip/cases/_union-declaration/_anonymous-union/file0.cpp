struct widget{
    union{
        long id_num;
    }
}