union month
{
    int s[2]; 
    float c;    
};  