template <typename T>
void manipulate(T* ptr) {
    // Manipulation logic
}

void templateExample() {
    double num = 3.14;
    manipulate(&num);
}