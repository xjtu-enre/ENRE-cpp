void processElement(int* elementPtr) {
    // Processing logic
}

void arrayExample() {
    int arr[5] = {1, 2, 3, 4, 5};
    processElement(&arr[2]);
}