namespace ns{}
using namespace ns;