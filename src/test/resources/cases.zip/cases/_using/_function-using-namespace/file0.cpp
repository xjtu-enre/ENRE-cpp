namespace ns{}
void func(){
    using namespace ns;
}