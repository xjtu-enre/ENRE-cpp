class A{
    public: void func();
}
class B : public A{
    public: void func();
}