class A{
    public: virtual void func();
}
class B : public A{
    public: void func();
}