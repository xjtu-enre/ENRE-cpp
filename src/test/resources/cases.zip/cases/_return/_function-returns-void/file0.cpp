void doSomething() {
    // Some code
}