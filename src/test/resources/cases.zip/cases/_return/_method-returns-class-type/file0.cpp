class MyClass {
public:
    MyClass getObject() {
        return MyClass();
    }
};