class MyClass {
public:
    int* getPointer() {
        return new int(10);
    }
};