template <typename T>
T getTemplateObject() {
    return T();
}