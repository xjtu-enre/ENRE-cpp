class MyClass {};

int main() {
    MyClass* obj = new MyClass();
    delete obj;
}