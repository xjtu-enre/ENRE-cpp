int main() {
    int* arr = new int[10];
    delete[] arr;
}