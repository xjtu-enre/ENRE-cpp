#define dou double
int main(){
    dou number;
}