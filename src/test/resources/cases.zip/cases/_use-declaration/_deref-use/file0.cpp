int func(int i){
    int a,*b=0;
    a = *b; 
}