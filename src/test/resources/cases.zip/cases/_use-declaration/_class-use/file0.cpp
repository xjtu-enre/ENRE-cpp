class A{ /* empty */ }
int main(){
    A a;
}