class A{
public:
    int x;
    int func(){
        return x;
    }
}