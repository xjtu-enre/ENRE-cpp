extern int var1;
int func() {
    int local_var = var1; // use of var1
}