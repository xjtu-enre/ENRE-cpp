int func(int array[]) {
    return -1;
}