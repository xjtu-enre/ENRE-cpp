int func(int i){
    return i;
}