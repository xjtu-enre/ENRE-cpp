namespace MyNamespace {
    void someFunction() {}
}