void outerFunction() {
    class LocalClass {};
}