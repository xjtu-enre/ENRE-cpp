class MyClass {
public:
    int memberVar;
    void memberFunc() {}
};