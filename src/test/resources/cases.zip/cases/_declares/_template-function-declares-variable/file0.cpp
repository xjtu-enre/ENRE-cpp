template <typename T>
void templateFunction() {
    T var;
}