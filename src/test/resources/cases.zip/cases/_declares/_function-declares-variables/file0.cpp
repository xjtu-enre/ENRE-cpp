void myFunction() {
    int a;
    double b;
}