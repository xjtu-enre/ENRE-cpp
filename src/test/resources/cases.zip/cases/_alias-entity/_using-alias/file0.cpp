namespace base{
    namespace flags{
        class child{
        };
    }
}
using flags = base::flags::child;