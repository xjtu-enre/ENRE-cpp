namespace ns{}
namespace text = ns;