class vector{};
template<class T>
using Vec = vector; 