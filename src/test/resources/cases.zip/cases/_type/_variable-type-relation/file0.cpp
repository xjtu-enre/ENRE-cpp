int main() {
    int count = 0;
    double price = 10.99;
}