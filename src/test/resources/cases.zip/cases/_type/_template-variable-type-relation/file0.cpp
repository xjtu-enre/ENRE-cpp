template<typename T>
void processValue(T value) {
    T result = value * 2;
}