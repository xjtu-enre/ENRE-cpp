class Student {
public:
    int age;
    std::string name;
};
