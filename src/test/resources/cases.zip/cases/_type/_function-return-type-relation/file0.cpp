int calculateSum(int a, int b) {
    return a + b;
}

double getArea(double radius) {
    return 3.14 * radius * radius;
}