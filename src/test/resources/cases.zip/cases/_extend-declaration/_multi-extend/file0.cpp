class Collection { };
class Book {};
class CollectionOfBook : public Book, public Collection {};