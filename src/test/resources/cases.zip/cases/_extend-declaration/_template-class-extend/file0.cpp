template<class T>
class Base<T>{};
class Derived : public Base<std::string>{};