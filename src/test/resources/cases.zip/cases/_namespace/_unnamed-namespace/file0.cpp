namespace{
    int i; 
}