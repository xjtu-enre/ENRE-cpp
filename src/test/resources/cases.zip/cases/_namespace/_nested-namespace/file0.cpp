namespace foo {
    namespace bar {
         namespace baz {
             int qux = 42;
         }
    }
}