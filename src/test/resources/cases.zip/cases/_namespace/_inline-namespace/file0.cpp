namespace Test{
    inline namespace new_ns { \* empty *\  }
}