int getValue() {
    return 42;
}

int main() {
    int val = getValue(); // Flow from 'getValue()' to 'val'
}