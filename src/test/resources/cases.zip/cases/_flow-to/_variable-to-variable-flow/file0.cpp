int main() {
    int a = 5;
    int b = a;  // Flow from 'a' to 'b'
}