
template<class T> void f(T) { }
template void f<int> (int);