template<typename T, template<typename U, int I> class Arr>
class tuple
{ /* empty */ };