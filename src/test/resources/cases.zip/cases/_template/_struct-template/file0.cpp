template<typename T>
struct S{};