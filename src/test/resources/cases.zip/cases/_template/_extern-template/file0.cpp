template<typename T> class tuple;
extern template class tuple<int>;