template<class T>
void func(T x);