template<typename T>
class S{};