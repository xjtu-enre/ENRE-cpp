template <typename K, typename V>
class MyMap{ /* Empty */ };
template<typename V>
class MyMap<string, V> { /* Empty */ };