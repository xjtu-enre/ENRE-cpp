int main() {
  double d = 3.14;
  int i = (int)d;
}