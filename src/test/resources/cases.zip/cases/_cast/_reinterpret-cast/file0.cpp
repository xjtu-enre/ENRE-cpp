int main() {
    int i = 42;
    char* c = reinterpret_cast<char*>(&i);
}