int main() {
    float f = 3.14;
    int i = static_cast<int>(f);
}