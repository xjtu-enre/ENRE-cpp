typedef enum{
    Monday = 1,
    Tuesday
} Weekday;