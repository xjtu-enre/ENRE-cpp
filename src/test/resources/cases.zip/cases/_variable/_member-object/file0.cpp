class c{
private:
    int member;
}