#include <iostream>

int main() {
    auto x = 42;
    std::cout << "x = " << x << std::endl;
    return 0;
}