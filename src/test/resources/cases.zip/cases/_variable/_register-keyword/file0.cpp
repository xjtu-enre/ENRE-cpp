int main() {
    register int x = 42;
    std::cout << "x = " << x << std::endl;
    return 0;
}