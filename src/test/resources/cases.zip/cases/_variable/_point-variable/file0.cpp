int a = 0;
int *p = &a;